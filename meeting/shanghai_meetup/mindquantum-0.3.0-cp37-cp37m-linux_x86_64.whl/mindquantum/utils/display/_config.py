# Copyright 2021 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Configuration"""

from rich.console import Console

_tmp_console = Console()
if _tmp_console.is_jupyter:
    from IPython.core.display import HTML, display
    display(HTML("<style>pre { white-space: pre !important; }</style>"))

_res_text_drawer_config = {
    'vline': '│',
    'max_size': 60,
    'spilit': 5,
    'hline': '─',
    'cross_mask': '┼',
    'axis_mask': '┴',
    'box_high': '▓',
    'box_low': '▒',
    'deci': 3,
}

_text_drawer_config = {
    'ctrl_mask': '●',  #⨉
    'circ_line': '─',
    'ctrl_line': '│',
    'cross_mask': '┼',
    'v_n': 1,
    'swap_mask': ['✖', '✖'],  # ✖, ⨯⨯
    'edge_num': 2,
    'barrier': '‖'
}

_text_drawer_config['edge'] = _text_drawer_config[
    'circ_line'] * _text_drawer_config['edge_num']

_CIRCUIT_STYLE = 'blue'
_MEA_RES_STYLE = 'yellow'
_DAGGER_MASK = '†'

# Copyright 2021 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""hiqqasm"""
import numpy as np
from .openqasm import _find_qubit_id
from .openqasm import u3

HIQASM_GATE_SET = {
    '0.1': {
        'np': ['X', 'Y', 'Z', 'S', 'T', 'H', 'CNOT', 'CZ', 'ISWAP', 'CCNOT'],
        'p': [
            'RX', 'RY', 'RZ', 'U', 'CRX', 'CRY', 'CRZ', 'XX', 'YY', 'ZZ',
            'CCRX', 'CCRY', 'CCRZ'
        ],
    }
}


def random_hiqasm(n_qubits, gate_num, version='0.1', seed=42):
    """
    Generate random hiqasm supported circuit.

    Args:
        n_qubits (int): Total number of qubit in this quantum circuit.
        gate_num (int): Total number of gate in this quantum circuit.
        version (str): version of HIQASM. Default: '0.1'.
        seed (int): The random seed to generate this random quantum circuit.

    Returns:
        str, quantum in HIQASM format.
    """
    if not isinstance(n_qubits, (int, np.int64)) or n_qubits < 1:
        raise ValueError(
            f'qubit number should be a non negative int, but get {n_qubits}.')
    if not isinstance(gate_num, (int, np.int64)) or gate_num < 1:
        raise ValueError(
            f'gate number should be a non negative int, but get {n_qubits}.')
    np.random.seed(seed)
    gate_set = HIQASM_GATE_SET[version]
    np_set = gate_set['np']
    p_set = gate_set['p']
    if version == '0.1':
        qasm = [
            '# HIQASM 0.1', '# Instruction stdins', '', 'ALLOCATE q',
            f'RESET q {n_qubits}'
        ]
        if n_qubits == 1:
            np_set = np_set[:6]
            p_set = p_set[:4]
        elif n_qubits == 2:
            np_set = np_set[:9]
            p_set = p_set[:10]
        while len(qasm) - 5 < gate_num:
            g_set = np.random.choice([np_set, p_set])
            gate = np.random.choice(g_set)
            pval = np.random.uniform(-np.pi, np.pi, 3)
            qidx = np.arange(n_qubits)
            np.random.shuffle(qidx)
            if gate in ['X', 'Y', 'Z', 'S', 'T', 'H']:
                qasm.append(f'{gate} q[{qidx[0]}]')
            elif gate in ['CNOT', 'CZ', 'ISWAP']:
                qasm.append(f'{gate} q[{qidx[0]}],q[{qidx[1]}]')
            elif gate == 'CCNOT':
                qasm.append('{} q[{}],q[{}],q[{}]'.format(gate, *qidx[:3]))
            elif gate in ['RX', 'RY', 'RZ']:
                qasm.append(f'{gate} q[{qidx[0]}] {pval[0]}')
            elif gate == 'U':
                qasm.append('U q[{}] {},{},{}'.format(qidx[0], *pval))
            elif gate in ['CRX', 'CRY', 'CRZ', 'XX', 'YY', 'ZZ']:
                qasm.append('{} q[{}],q[{}] {}'.format(gate, *qidx[:2],
                                                       pval[0]))
            elif gate in ['CCRX', 'CCRY', 'CCRZ']:
                qasm.append('{} q[{}],q[{}],q[{}] {}'.format(
                    gate, *qidx[:3], pval[0]))
            else:
                raise NotImplementedError(
                    f"gate {gate} not implement in HIQASM {version}")
        qasm.append('MEASURE q')
        qasm.append('DEALLOCATE q')
        qasm.append('')
        return '\n'.join(qasm)
    raise NotImplementedError(f'version {version} not implemented')


class HiQASM:
    """
    Convert a circuit to hiqasm format.
    """
    def __init__(self):
        from mindquantum import Circuit
        self.circuit = Circuit()
        self.cmds = []

    def filter(self, cmds):
        """filter empty cmds and head."""
        out = []
        version = None
        for cmd in cmds:
            cmd = cmd.strip()
            if not cmd:
                continue
            if startswithany(cmd, '#', 'ALLOCATE', 'RESET', 'MEASURE',
                             'DEALLOCATE'):
                if cmd.startswith('# HIQASM'):
                    version = cmd.split(' ')[-1]
                continue
            out.append(cmd)
        return out, version

    def from_file(self, file_name):
        """Read a hiqasm file"""
        with open(file_name, 'r') as f:
            cmds = f.readlines()
        self.cmds, version = self.filter(cmds)
        if version == '0.1':
            self.trans_v01(self.cmds)
        else:
            raise ValueError(f'HIQASM {version} not implement yet')

    def trans_v01(self, cmds):
        """Trans method for hiqasm version 0.1"""
        from mindquantum import Circuit
        import mindquantum.gate as G
        self.circuit = Circuit()
        for cmd in cmds:
            q = _find_qubit_id(cmd)
            if cmd.startswith('H '):
                self.circuit.h(q[0])
            elif cmd.startswith('X '):
                self.circuit.x(q[0])
            elif cmd.startswith('Y '):
                self.circuit.y(q[0])
            elif cmd.startswith('Z '):
                self.circuit.z(q[0])
            elif cmd.startswith('S '):
                self.circuit += G.S.on(q[0])
            elif cmd.startswith('T '):
                self.circuit += G.T.on(q[0])
            elif cmd.startswith('CNOT '):
                self.circuit.x(q[1], q[0])
            elif cmd.startswith('CZ '):
                self.circuit.z(q[1], q[0])
            elif cmd.startswith('ISWAP '):
                self.circuit += G.ISWAP.on(q[:2])
            elif cmd.startswith('CCNOT '):
                self.circuit.x(q[-1], q[:2])
            elif cmd.startswith('RX '):
                self.circuit.rx(*_extr_parameter(cmd), q[0])
            elif cmd.startswith('RY '):
                self.circuit.ry(*_extr_parameter(cmd), q[0])
            elif cmd.startswith('RZ '):
                self.circuit.rz(*_extr_parameter(cmd), q[0])
            elif cmd.startswith('U '):
                self.circuit += u3(*_extr_parameter(cmd), q[0])
            elif cmd.startswith('CRX '):
                self.circuit.rx(*_extr_parameter(cmd), q[1], q[0])
            elif cmd.startswith('CRY '):
                self.circuit.ry(*_extr_parameter(cmd), q[1], q[0])
            elif cmd.startswith('CRZ '):
                self.circuit.rz(*_extr_parameter(cmd), q[1], q[0])
            elif cmd.startswith('XX '):
                self.circuit.xx(*_extr_parameter(cmd), q[:2])
            elif cmd.startswith('YY '):
                self.circuit.yy(*_extr_parameter(cmd), q[:2])
            elif cmd.startswith('ZZ '):
                self.circuit.zz(*_extr_parameter(cmd), q[:2])
            elif cmd.startswith('CCRX '):
                self.circuit.rx(*_extr_parameter(cmd), q[-1], q[:2])
            elif cmd.startswith('CCRY '):
                self.circuit.ry(*_extr_parameter(cmd), q[-1], q[:2])
            elif cmd.startswith('CCRZ '):
                self.circuit.rz(*_extr_parameter(cmd), q[-1], q[:2])
            else:
                raise ValueError(f"transfer cmd {cmd} not implement yet!")


def _extr_parameter(cmd):
    """extra parameter for parameterized gate in hiqasm cmd"""
    return [float(i) for i in cmd.split(' ')[-1].split(',')]


def startswithany(cmd, *s):
    """Checkout whether cmd starts with any string in s"""
    for i in s:
        if cmd.startswith(i):
            return True
    return False


if __name__ == '__main__':
    print(random_hiqasm(1, 10))

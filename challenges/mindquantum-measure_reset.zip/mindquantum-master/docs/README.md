# MindQuantum 中文英文文档编写注意事项

需翻译专业词汇

|English|中文|
|-|-|
|Hermitian|厄米|
|Hermitian conjugate|厄米共轭|
|Qubit|量子比特|
|Quantum Circuit|量子线路|
|Hamiltonian|哈密顿量|
|Fermion|费米子|
|Pauli|泡利算符|
|Pauli word|泡利词|
|Pauli string|泡利句|

可以不翻译的词汇

|英文词汇|
|-|
|ansatz|

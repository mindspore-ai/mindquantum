mindquantum.algorithm.library
==============================

.. automodule:: mindquantum.algorithm.library

.. autosummary::
    :toctree:
    :nosignatures:
    :template: classtemplate.rst

    mindquantum.algorithm.library.amplitude_encoder
    mindquantum.algorithm.library.bitphaseflip_operator
    mindquantum.algorithm.library.general_ghz_state
    mindquantum.algorithm.library.general_w_state
    mindquantum.algorithm.library.qft

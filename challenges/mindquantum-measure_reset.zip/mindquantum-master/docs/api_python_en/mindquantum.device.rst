mindquantum.device
==================

.. automodule:: mindquantum.device

Class
-----

.. autosummary::
    :toctree:
    :nosignatures:
    :template: classtemplate.rst

    mindquantum.device.QubitNode
    mindquantum.device.QubitsTopology
    mindquantum.device.GridQubits
    mindquantum.device.LinearQubits

mindquantum.core.circuit.MeasureAccepter
========================================

.. py:class:: mindquantum.core.circuit.MeasureAccepter()

    选取测量门。

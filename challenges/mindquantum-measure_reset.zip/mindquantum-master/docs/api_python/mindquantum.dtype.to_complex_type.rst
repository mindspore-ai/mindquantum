mindquantum.dtype.to_complex_type
=================================

.. py:function:: mindquantum.dtype.to_complex_type(dtype)

    将一个类型转化为复数类型，并保持精度不变。

    参数：
        - **dtype** (mindquantum.dtype) - MindQuantum 支持的类型。

mindquantum.algorithm.compiler.CZToCX
=====================================

.. py:class:: mindquantum.algorithm.compiler.CZToCX()

    将 ``cz`` 门编译为 ``cx`` 门。

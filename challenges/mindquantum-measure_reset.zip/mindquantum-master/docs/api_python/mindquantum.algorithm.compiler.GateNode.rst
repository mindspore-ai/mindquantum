mindquantum.algorithm.compiler.GateNode
=======================================

.. py:class:: mindquantum.algorithm.compiler.GateNode(gate: gates.BasicGate)

    DAG 图中作为量子门的节点。

    参数：
        - **gate** (:class:`~.core.gates.BasicGate`) - 量子门。

mindquantum.core.circuit.NoiseExcluder
========================================

.. py:class:: mindquantum.core.circuit.NoiseExcluder(add_after=True)

    排除噪声门。

    参数：
        - **add_after** (bool) - 在量子门前面或者后面添加量子信道。默认值： ``True``。

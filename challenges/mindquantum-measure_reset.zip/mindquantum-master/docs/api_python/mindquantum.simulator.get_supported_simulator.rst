mindquantum.simulator.get_supported_simulator
==============================================

.. py:function:: mindquantum.simulator.get_supported_simulator()

    获取MindQuantum支持的模拟器名称。

    返回：
        list，支持的模拟器列表。

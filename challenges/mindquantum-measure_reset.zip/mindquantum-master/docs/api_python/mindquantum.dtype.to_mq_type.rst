mindquantum.dtype.to_mq_type
============================

.. py:function:: mindquantum.dtype.to_mq_type(dtype)

    将一个类型转化为mindquantum中支持的类型。

    参数：
        - **dtype** (Union[mindquantum.dtype, mindspore.dtype, numpy.dtype]) - MindQuantum 或 MindSpore 或 numpy 支持的类型。

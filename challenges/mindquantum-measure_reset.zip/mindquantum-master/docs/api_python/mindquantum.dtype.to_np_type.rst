mindquantum.dtype.to_np_type
============================

.. py:function:: mindquantum.dtype.to_np_type(dtype)

    将一个类型转化为numpy中的类型。

    参数：
        - **dtype** (mindquantum.dtype) - MindQuantum 支持的类型。

mindquantum.dtype.to_precision_like
===================================

.. py:function:: mindquantum.dtype.to_precision_like(dtype_src, dtype_des)

    将一个类型转为跟目标类型精度相同的类型。

    参数：
        - **dtype_src** (mindquantum.dtype) - MindQuantum 支持的类型。
        - **dtype_des** (mindquantum.dtype) - MindQuantum 支持的类型。

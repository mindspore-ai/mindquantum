mindquantum.algorithm.compiler.DAGQubitNode
===========================================

.. py:class:: mindquantum.algorithm.compiler.DAGQubitNode(qubit: int)

    DAG 图中作为量子比特的节点。

    参数：
        - **qubit** (int) - 量子比特的编号。

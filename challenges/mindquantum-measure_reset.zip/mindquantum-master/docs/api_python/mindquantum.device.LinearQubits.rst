mindquantum.device.LinearQubits
===============================

.. py:class:: mindquantum.device.LinearQubits(n_qubits: int)

    线性的量子比特拓扑结构。

    参数：
        - **n_qubits** (int) - 总的比特数。

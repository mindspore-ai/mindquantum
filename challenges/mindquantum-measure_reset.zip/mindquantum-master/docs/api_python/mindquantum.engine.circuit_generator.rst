.. py:function:: mindquantum.engine.circuit_generator(n_qubits, *args, **kwds)

    生成projectq格式的量子线路。

    参数：
        - **n_qubits** (int) - 量子线路的量子比特数。

mindquantum.dtype.precision_str
===============================

.. py:function:: mindquantum.dtype.precision_str(dtype)

    返回精度的字符串。

    参数：
        - **dtype** (mindquantum.dtype) - MindQuantum 支持的类型。

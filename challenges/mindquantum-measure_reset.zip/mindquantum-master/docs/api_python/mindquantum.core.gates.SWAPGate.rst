mindquantum.core.gates.SWAPGate
================================

.. py:class:: mindquantum.core.gates.SWAPGate

    SWAP门可以交换两个不同的量子比特。

    更多用法，请参见 :class:`~.core.gates.XGate`。

    .. py:method:: get_cpp_obj()

        返回该门的c++对象。

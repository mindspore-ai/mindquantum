mindquantum.algorithm.compiler.CXToCZ
=====================================

.. py:class:: mindquantum.algorithm.compiler.CXToCZ()

    将 ``cx`` 门编译为 ``cz`` 门。

mindquantum.dtype.to_real_type
==============================

.. py:function:: mindquantum.dtype.to_real_type(dtype)

    将一个类型转化为实数类型，并保持精度不变。

    参数：
        - **dtype** (mindquantum.dtype) - MindQuantum 支持的类型。

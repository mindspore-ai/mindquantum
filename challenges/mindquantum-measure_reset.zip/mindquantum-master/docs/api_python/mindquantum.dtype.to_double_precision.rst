mindquantum.dtype.to_double_precision
=====================================

.. py:function:: mindquantum.dtype.to_double_precision(dtype)

    将一个类型转化为双精度类型。

    参数：
        - **dtype** (mindquantum.dtype) - MindQuantum 支持的类型。

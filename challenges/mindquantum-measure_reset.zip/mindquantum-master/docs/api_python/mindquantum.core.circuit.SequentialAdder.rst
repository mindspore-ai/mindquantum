mindquantum.core.circuit.SequentialAdder
========================================

.. py:class:: mindquantum.core.circuit.SequentialAdder(adders: typing.List[ChannelAdderBase])

    依次执行每一个添加器。

    参数：
        - **adders** (List[:class:`~.core.circuit.ChannelAdderBase`]) - 想要执行的 adder 。

mindquantum.core.circuit.ReverseAdder
=====================================

.. py:class:: mindquantum.core.circuit.ReverseAdder(adder: ChannelAdderBase)

    翻转给定信道添加器的接受和拒绝规则。

    参数：
        - **adder** (:class:`~.core.circuit.ChannelAdderBase`) - 一个信道添加器。

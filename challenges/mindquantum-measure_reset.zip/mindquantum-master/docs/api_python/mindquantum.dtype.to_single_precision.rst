mindquantum.dtype.to_single_precision
=====================================

.. py:function:: mindquantum.dtype.to_single_precision(dtype)

    将一个类型转化为单精度类型。

    参数：
        - **dtype** (mindquantum.dtype) - MindQuantum 支持的类型。

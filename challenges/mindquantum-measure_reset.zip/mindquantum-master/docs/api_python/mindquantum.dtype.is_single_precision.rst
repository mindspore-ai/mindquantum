mindquantum.dtype.is_single_precision
=====================================

.. py:function:: mindquantum.dtype.is_single_precision(dtype)

    判断一个类型是不是单精度类型。

    参数：
        - **dtype** (mindquantum.dtype) - MindQuantum 支持的类型。

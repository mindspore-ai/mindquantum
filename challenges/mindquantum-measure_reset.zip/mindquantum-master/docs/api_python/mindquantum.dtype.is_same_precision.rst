mindquantum.dtype.is_same_precision
===================================

.. py:function:: mindquantum.dtype.is_same_precision(dtype1, dtype2)

    判断两个类型的精度是否相同。

    参数：
        - **dtype1** (mindquantum.dtype) - MindQuantum 支持的类型。
        - **dtype1** (mindquantum.dtype) - MindQuantum 支持的类型。

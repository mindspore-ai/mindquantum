mindquantum.algorithm.compiler.FullyNeighborCanceler
====================================================

.. py:class:: mindquantum.algorithm.compiler.FullyNeighborCanceler()

    全量线路融合规则，会融合可能的临近量子门，直到不能融合为止。

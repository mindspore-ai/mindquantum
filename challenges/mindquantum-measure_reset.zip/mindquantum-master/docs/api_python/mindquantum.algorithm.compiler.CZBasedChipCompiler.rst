mindquantum.algorithm.compiler.CZBasedChipCompiler
==================================================

.. py:class:: mindquantum.algorithm.compiler.CZBasedChipCompiler(log_level=0)

    适用于支持 `cz` 量子门的量子芯片的编译规则。

    参数：
        - **log_level** (int) - log信息展示级别。可以为 ``0`` 、 ``1`` 或者 ``2`` 。默认值： ``0`` 。关于log级别的更多信息，请参考 :class:`~.algorithm.compiler.BasicCompilerRule` 。

mindquantum.dtype.is_double_precision
=====================================

.. py:function:: mindquantum.dtype.is_double_precision(dtype)

    判断一个类型是不是双精度类型。

    参数：
        - **dtype** (mindquantum.dtype) - MindQuantum 支持的类型。
